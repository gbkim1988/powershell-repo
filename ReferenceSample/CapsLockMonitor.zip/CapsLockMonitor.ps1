###################################################################
# CapsLockMonitor.ps1
#
# Wayne Lindimore
# wlindimore@gmail.com
# AdminsCache.Wordpress.com
#
# 5-23-13
# NotifyIcon Monitoring CapsLock, Notifies with Balloon and Voice
###################################################################
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Speech

function Get-ScriptDirectory { 
  $Invocation = (Get-Variable MyInvocation -Scope 1).Value
  $global:callPath = Split-Path $Invocation.MyCommand.Path
} # End Get-ScriptDirectory

# Main form and Setup
$mainForm = New-Object System.Windows.Forms.form
$global:lastCapsLock = [System.Console]::CapsLock
$global:callPath = ""
Get-ScriptDirectory
# Hide Main Form
$mainForm.ShowInTaskbar = $false
$mainForm.WindowState = "minimized"

# Timer Object
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 2000 
$timer.add_Tick({CapsLockCheck})
$timer.start()

# NotifyIcon Objects
$notifyIcon= New-Object System.Windows.Forms.NotifyIcon
$contextMenu = New-Object System.Windows.Forms.ContextMenu
$notifyIcon.ContextMenu = $contextMenu
$notifyIcon.Visible = $true
$menuItem1 = New-Object System.Windows.Forms.MenuItem -ArgumentList "Exit"
$contextMenu.MenuItems.Add($menuItem1)

# Add Exit MenuItem
$menuItem1.add_Click({
	$timer.stop()
	$mainForm.close()
})

# Inital Load
$capsLock = [System.Console]::CapsLock
if ($capsLock -eq $false) { 
            $notifyIcon.Icon = $global:callPath + "\down.ico"
            $notifyIcon.Text = "CapsLock is Off"
} 
if ($capsLock -eq $true) { 
            $notifyIcon.Icon = $global:callPath + "\up.ico"
            $notifyIcon.Text = "CapsLock is On"
} 

Function CapsLockCheck { 
    $capsLock = [System.Console]::CapsLock
    if ($capsLock -eq $false) { 
        if ($capsLock -ne $global:lastCapsLock) {
            $notifyIcon.Icon = $global:callPath + "\down.ico"
            $notifyIcon.Text = "CapsLock is Off"
            $notifyIcon.BalloonTipText = "CapsLock is Off"
            $notifyIcon.BalloonTipTitle = "CapsLock has Changed"
            $notifyIcon.BalloonTipIcon = "Info"
            $notifyIcon.ShowBalloonTip(10000)
            $spokenText = "Caps Lock is Off"
            $global:lastCapsLock = $capsLock
            VoiceNotification
        } 
    }
    if ($capsLock -eq $true) { 
        if ($capsLock -ne $global:lastCapsLock) {
            $notifyIcon.Icon = $global:callPath + "\up.ico"
            $notifyIcon.Text = "CapsLock is On"
            $notifyIcon.BalloonTipText = "CapsLock is On"
            $notifyIcon.BalloonTipTitle = "CapsLock has Changed"
            $notifyIcon.BalloonTipIcon = "Info"
            $notifyIcon.ShowBalloonTip(10000)
            $spokenText = "Caps Lock is On"
            $global:lastCapsLock = $capsLock
            VoiceNotification
        } 
    }
} # End Function CapsLockCheck

Function VoiceNotification {   
    $Voice = New-Object System.Speech.Synthesis.SpeechSynthesizer 
    $voice.rate = -1
    $voice.volume = 100
    [void] $voice.Speak($spokenText)
} # End Function VoiceNotification

[System.Windows.Forms.Application]::Run($mainForm)